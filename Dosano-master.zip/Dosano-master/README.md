***
SCRIPT: **Dosano**

   JOB: **Denial Of Service Attack[DosAttack]**
***

- **Tool ScreenShot**

![banner](https://user-images.githubusercontent.com/29546157/51805521-f39abb00-2276-11e9-8915-d4501f89a699.PNG)

![attack](https://user-images.githubusercontent.com/29546157/51805517-eda4da00-2276-11e9-8ccd-d6f1f680f8d2.PNG)
***

# Installing:
   - git clone https://github.com/Oseid/Dosano.git
   - cd Dosano/
   - perl dosano.pl
   
   * Download Complete !
   
***

# Supported Platforms:
- [x] Windows
- [x] Linux
- [x] Android~**Termux**
- [x] MacOs

***

# That's All :)
   * This Script By Oseid Aldary
   * Thanks For Usage
   * Have A Nice Day...GoodBye :)

***
